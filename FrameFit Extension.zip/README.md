# FrameFit 2.4.5

Video fullscreen inside your browser window. The menu includes overall and per-site
switches, compact-window, current-tab, or Picture-in-Picture mode, and four saved color themes.

Version 2.4.5 explicitly synchronizes YouTube's internal video and control sizes
when entering, resizing, and leaving FrameFit. Exit uses the current page size,
including delayed layout changes and later browser resizing in both tab and compact modes.
Compact-window sizing, fullscreen-button toggles, X/Twitter support, close
protection, and the dismissible tip remain. No floating Minimize control is added.
Reload the extension and existing video tabs after updating.

## Install or update

1. Exit any active FrameFit compact view.
2. Extract this package into a clean folder.
3. To retain existing preferences, replace the **entire contents** of the folder you
   originally loaded with this package's contents. This version reorganizes files;
   copying only changed files would leave obsolete files behind.
4. In `chrome://extensions`, reload FrameFit. For a first installation, enable
   Developer mode, select **Load unpacked**, and choose this folder.
5. Reload video tabs and pin FrameFit using Chrome's Extensions menu.

The extension card should show version **2.4.5**. Do not enable an older fullscreen
extension at the same time.

## Use

- Click a video's normal fullscreen button.
- Click **Return to tab · Esc** or press **Escape** to restore the normal page and
  move the same video tab back to its browser window. Playback is not reloaded.
- In fill-current-tab mode, **Return to page · Esc** restores the normal page layout.
- **Alt+Shift+V** is the fallback shortcut for supported video elements.
- Twitch also supports **F**, except while typing in chat or other input fields.
- Click FrameFit's toolbar icon to change settings and select **Light purple**,
  **Turquoise**, **Chrome light**, or **Chrome dark**.

Compact windows retain Chrome's URL and title bars, while hiding tabs and bookmarks.
Use Escape to return; closing a compact window closes its video tab. The Chrome color
options are fixed palettes, not automatic matching of custom browser themes.

## Picture-in-Picture

Select **Picture-in-Picture** in the menu, then click the video's fullscreen button
or press **Alt+Shift+V** on the page. FrameFit adds no border or controls to the floating
video. Chrome and the operating system control its edges, shadow, and native controls;
FrameFit cannot remove those. Close it using Chrome's controls or toggle again from
the page. Escape on the video page closes a PiP window opened by FrameFit.

Some sites and embedded players prohibit PiP; a message appears when it is unavailable.
Choose another viewing mode in that case. Page-drawn subtitles and website controls
may not transfer to native video PiP. No unsupported browser security restrictions
are bypassed.

## Files

```text
manifest.json  Chrome configuration and permissions
ui/            Toolbar menu markup
scripts/       Player behavior, settings, menu, and window management
styles/        Menu themes and video layout
assets/        Icons and logo
README.md      Installation and usage
```

No build step, runtime libraries, test fixtures, or development tools are included
in this installable package. The separate source package contains tests and tooling.

## Permissions and privacy

HTTP/HTTPS page access lets FrameFit resize players and embedded frames. Chrome's
site-access controls can restrict where it runs. `activeTab` identifies the current
website when you open the menu. Local storage holds preferences and disabled website
hostnames; session storage holds window IDs, bounds, and tab position for restoration.
No tracking, uploads, remote scripts, or video URL storage are included.

## Compatibility and validation

The general behavior supports standard video Fullscreen API calls. YouTube,
X/Twitter, Twitch, and Crunchyroll have dedicated handlers. Some custom players, closed shadow roots, and
frames where Chrome cannot inject require additional compatibility work. Chrome
internal pages, the Chrome Web Store, local files, and native apps are unsupported.

This release received local browser-fixture checks, simulated Chrome API checks,
formatting checks, syntax checks, and an audit of packaged file references. It still
needs a final installed-Chrome smoke test. Earlier versions were reported working
on Crunchyroll and Twitch by the user.

## Compact close protection

Confirm before closing defaults on and can be changed in the menu. While compact
view is active, Chrome may show its generic Leave/Cancel warning when closing,
reloading, or navigating. Browser interaction rules still apply. Return to tab and
Escape remove FrameFit close protection without closing the video. The compact tip can be dismissed for this page or
hidden permanently with its checkbox. Rounded menu styling does not change the
Chrome/Windows outer window frame.

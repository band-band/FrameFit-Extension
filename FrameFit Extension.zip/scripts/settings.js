'use strict';
globalThis.FrameFitSettings = {
  keys: [
    'framefitEnabled',
    'framefitMode',
    'framefitDisabledSites',
    'framefitTheme',
    'framefitConfirmClose',
    'framefitHideCompactTip',
  ],
  themes: ['purple', 'turquoise', 'chrome-light', 'chrome-dark'],
  hostname(url) {
    try {
      const u = new URL(url);
      return /^https?:$/.test(u.protocol) ? u.hostname.replace(/^www\./, '') : '';
    } catch {
      return '';
    }
  },
  async read() {
    const saved = await chrome.storage.local.get(this.keys);
    return {
      enabled: saved.framefitEnabled !== false,
      confirmClose: saved.framefitConfirmClose !== false,
      hideCompactTip: saved.framefitHideCompactTip === true,
      mode: ['tab', 'pip'].includes(saved.framefitMode) ? saved.framefitMode : 'compact',
      theme: this.themes.includes(saved.framefitTheme) ? saved.framefitTheme : 'purple',
      disabledSites: Array.isArray(saved.framefitDisabledSites)
        ? saved.framefitDisabledSites.filter((x) => typeof x === 'string')
        : [],
    };
  },
  effective(settings, url) {
    const host = this.hostname(url);
    return {
      enabled: Boolean(
        host && settings.enabled && !settings.disabledSites.includes(host),
      ),
      mode: settings.mode,
      confirmClose: settings.confirmClose,
      hideCompactTip: settings.hideCompactTip,
    };
  },
};

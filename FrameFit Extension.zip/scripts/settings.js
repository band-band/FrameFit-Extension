'use strict';
globalThis.FrameFitSettings = {
  keys: [
    'framefitEnabled',
    'framefitMode',
    'framefitEnabledSites',
    'framefitTheme',
    'framefitConfirmClose',
    'framefitHideCompactTip',
  ],
  themes: ['studio-dark', 'studio-light'],
  hostname(url) {
    try {
      const u = new URL(url);
      return /^https?:$/.test(u.protocol) ? u.hostname.replace(/^www\./, '') : '';
    } catch {
      return '';
    }
  },
  async read() {
    const saved = await chrome.storage.local.get(this.keys);
    return {
      enabled: saved.framefitEnabled !== false,
      confirmClose: saved.framefitConfirmClose !== false,
      hideCompactTip: saved.framefitHideCompactTip === true,
      mode: ['tab', 'pip', 'takeover'].includes(saved.framefitMode)
        ? saved.framefitMode
        : 'compact',
      theme: this.themes.includes(saved.framefitTheme)
        ? saved.framefitTheme
        : saved.framefitTheme === 'chrome-light'
          ? 'studio-light'
          : 'studio-dark',
      enabledSites: Array.isArray(saved.framefitEnabledSites)
        ? saved.framefitEnabledSites.filter((x) => typeof x === 'string')
        : [],
    };
  },
  effective(settings, url) {
    const host = this.hostname(url);
    return {
      enabled: Boolean(host && settings.enabled && settings.enabledSites.includes(host)),
      mode: settings.mode,
      confirmClose: settings.confirmClose,
      hideCompactTip: settings.hideCompactTip,
    };
  },
};

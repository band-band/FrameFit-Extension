'use strict';
const enabled = document.querySelector('#enabled');
const siteEnabled = document.querySelector('#site-enabled');
const fieldset = document.querySelector('#view-mode');
const status = document.querySelector('#status');
const theme = document.querySelector('#theme');
const confirmClose = document.querySelector('#confirm-close');
const showTips = document.querySelector('#show-tips');
const settingsButton = document.querySelector('#settings-button');
const descriptions = {
  tab: ['Theater Mode', 'Fill the page.', 'Keep your tabs and address bar.'],
  compact: [
    'Tab View',
    'Give video its own window.',
    'Keep the full player controls and URL bar.',
  ],
  pip: [
    'Picture in Picture',
    'Keep video in sight.',
    'Float above other apps. Some videos do not allow PiP.',
  ],
};
let host = '',
  preferences,
  busy = false;
function render() {
  document.documentElement.dataset.theme = preferences.theme;
  document.body.dataset.enabled = String(preferences.enabled);
  theme.value = preferences.theme;
  theme.disabled = busy;
  confirmClose.checked = preferences.confirmClose;
  confirmClose.disabled = busy;
  showTips.checked = !preferences.hideCompactTip;
  showTips.disabled = busy;
  enabled.checked = preferences.enabled;
  enabled.disabled = busy;
  siteEnabled.checked = Boolean(host && preferences.enabledSites.includes(host));
  siteEnabled.disabled = busy || !host;
  fieldset.disabled = busy;
  document.querySelector('#site-name').textContent = host || 'No supported website';
  document.querySelector('#site-note').textContent = host
    ? 'Enable on this site'
    : 'Open an HTTP or HTTPS video page';
  document.querySelector(`input[name="mode"][value="${preferences.mode}"]`).checked =
    true;
  const [name, title, detail] = descriptions[preferences.mode];
  const preview = document.querySelector('#mode-preview');
  preview.dataset.mode = preferences.mode;
  preview.setAttribute('aria-label', `${name} layout preview`);
  document.querySelector('#mode-description strong').textContent = title;
  document.querySelector('#mode-description span').textContent = detail;
  status.classList.remove('error');
  status.textContent = '';
}
async function save(patch) {
  if (busy) return;
  busy = true;
  render();
  try {
    await chrome.storage.local.set(patch);
    preferences = await FrameFitSettings.read();
    busy = false;
    render();
  } catch (error) {
    busy = false;
    render();
    status.classList.add('error');
    status.textContent = 'Could not save. Try again: ' + error.message;
  }
}
function showPreferences(show) {
  document.querySelector('#home').hidden = show;
  document.querySelector('#preferences').hidden = !show;
  settingsButton.setAttribute('aria-expanded', String(show));
  settingsButton.querySelector('span').textContent = show ? 'Back' : 'Settings';
  (show ? document.querySelector('#back') : settingsButton).focus();
}
settingsButton.addEventListener('click', () =>
  showPreferences(document.querySelector('#preferences').hidden),
);
document.querySelector('#back').addEventListener('click', () => showPreferences(false));
enabled.addEventListener('change', () => save({ framefitEnabled: enabled.checked }));
confirmClose.addEventListener('change', () =>
  save({ framefitConfirmClose: confirmClose.checked }),
);
showTips.addEventListener('change', () =>
  save({ framefitHideCompactTip: !showTips.checked }),
);
theme.addEventListener('change', () => save({ framefitTheme: theme.value }));
siteEnabled.addEventListener('change', () => {
  const sites = preferences.enabledSites.filter((site) => site !== host);
  if (siteEnabled.checked && host) sites.push(host);
  save({ framefitEnabledSites: sites });
});
document.querySelectorAll('input[name="mode"]').forEach((input) =>
  input.addEventListener('change', () => {
    if (input.checked) save({ framefitMode: input.value });
  }),
);
(async () => {
  try {
    const [tabs, saved] = await Promise.all([
      chrome.tabs.query({ active: true, currentWindow: true }),
      FrameFitSettings.read(),
    ]);
    host = FrameFitSettings.hostname(tabs[0]?.url);
    preferences = saved;
    document.querySelector('#version').textContent = chrome.runtime.getManifest().version;
    render();
  } catch (error) {
    status.classList.add('error');
    status.textContent = 'Could not load settings: ' + error.message;
  }
})();

'use strict';
const enabled = document.querySelector('#enabled');
const siteEnabled = document.querySelector('#site-enabled');
const fieldset = document.querySelector('#view-mode');
const status = document.querySelector('#status');
const theme = document.querySelector('#theme');
const confirmClose = document.querySelector('#confirm-close');
let host = '',
  preferences,
  busy = false;
function render() {
  document.documentElement.dataset.theme = preferences.theme;
  theme.value = preferences.theme;
  theme.disabled = busy;
  confirmClose.checked = preferences.confirmClose;
  confirmClose.disabled = busy;
  enabled.checked = preferences.enabled;
  enabled.disabled = busy;
  siteEnabled.checked = Boolean(host && !preferences.disabledSites.includes(host));
  siteEnabled.disabled = busy || !host;
  fieldset.disabled = busy;
  document.querySelector('#pip-note').hidden = preferences.mode !== 'pip';
  document.querySelector('#site-name').textContent =
    host || 'Open a video website to use this switch';
  document.querySelector('#enabled-note').textContent = preferences.enabled
    ? 'Ready when you go fullscreen'
    : 'Normal browser fullscreen is restored';
  document.querySelector(`input[name="mode"][value="${preferences.mode}"]`).checked =
    true;
  status.classList.remove('error');
  status.textContent = !preferences.enabled
    ? 'FrameFit is off on every website.'
    : host && preferences.disabledSites.includes(host)
      ? 'FrameFit is off on this website.'
      : 'Ready on this website. Changes save automatically.';
}
async function save(patch) {
  if (busy) return;
  busy = true;
  render();
  try {
    await chrome.storage.local.set(patch);
    preferences = await FrameFitSettings.read();
    busy = false;
    render();
  } catch (error) {
    busy = false;
    render();
    status.classList.add('error');
    status.textContent = 'Could not save. Try again: ' + error.message;
  }
}
enabled.addEventListener('change', () => save({ framefitEnabled: enabled.checked }));
confirmClose.addEventListener('change', () =>
  save({ framefitConfirmClose: confirmClose.checked }),
);

theme.addEventListener('change', () => save({ framefitTheme: theme.value }));
siteEnabled.addEventListener('change', () => {
  const sites = preferences.disabledSites.filter((site) => site !== host);
  if (!siteEnabled.checked) sites.push(host);
  save({ framefitDisabledSites: sites });
});
document.querySelectorAll('input[name="mode"]').forEach((input) =>
  input.addEventListener('change', () => {
    if (input.checked) save({ framefitMode: input.value });
  }),
);
(async () => {
  try {
    const [tabs, saved] = await Promise.all([
      chrome.tabs.query({ active: true, currentWindow: true }),
      FrameFitSettings.read(),
    ]);
    host = FrameFitSettings.hostname(tabs[0]?.url);
    preferences = saved;
    render();
  } catch (error) {
    status.classList.add('error');
    status.textContent = 'Could not load settings: ' + error.message;
  }
})();

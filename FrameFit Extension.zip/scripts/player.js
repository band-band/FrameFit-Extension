(() => {
  'use strict';
  const MESSAGE = 'video-compact-window-v2';
  const twitchSite =
    location.hostname === 'twitch.tv' || location.hostname.endsWith('.twitch.tv');
  const youtubeSite =
    location.hostname === 'youtube.com' || location.hostname.endsWith('.youtube.com');
  const YOUTUBE_PLAYER = '.html5-video-player';
  const xSite = ['x.com', 'twitter.com'].some(
    (host) => location.hostname === host || location.hostname.endsWith('.' + host),
  );
  const X_PLAYER = '[data-testid="videoComponent"]';
  const TWITCH_PLAYER = '[data-a-target="video-player"]';
  const TWITCH_BUTTON = '[data-a-target="player-fullscreen-button"]';
  let active = null,
    child = null,
    exitButton = null,
    focusBefore = null,
    scrollBefore = null,
    route = '';
  let pointer = null;
  let pipVideo = null;
  let pipRequest = null;
  let pipGeneration = 0;
  let layoutFrame = 0;
  let resizeFrame = 0;
  let youtubeLayout = null;
  let notice = null;
  let noticeTimer;
  let settings = { enabled: false, mode: 'compact' };
  const marked = new Map();
  function applySettings(value) {
    const oldMode = settings.mode;
    settings = {
      enabled: value?.enabled === true,
      mode: ['tab', 'pip'].includes(value?.mode) ? value.mode : 'compact',
    };
    if (!settings.enabled) {
      leave();
      youtubeLayout?.sync(true);
      stopYouTubeLayout();
    }
    if (!settings.enabled || settings.mode !== 'pip') {
      pipGeneration++;
      closePip().catch(() => {});
    }
    if (settings.mode === 'pip' && oldMode !== 'pip') {
      leave();
      youtubeLayout?.sync(true);
      stopYouTubeLayout();
    }
    labelExitButton();
    window.removeEventListener('pointermove', trackPointer);
    if (settings.enabled)
      window.addEventListener('pointermove', trackPointer, { passive: true });
    else pointer = null;
    for (const frame of document.querySelectorAll('iframe')) {
      frame.contentWindow?.postMessage(
        { channel: MESSAGE, type: 'settings', settings },
        '*',
      );
    }
  }
  function readSettings() {
    if (window !== top) return;
    try {
      applySettings(
        JSON.parse(
          document.documentElement?.getAttribute('data-framefit-settings') || '{}',
        ),
      );
    } catch {}
  }
  document.addEventListener('framefit-settings', readSettings);

  function mark(element, name) {
    if (element.classList.contains(name)) return;
    element.classList.add(name);
    if (!marked.has(element)) marked.set(element, new Set());
    marked.get(element).add(name);
  }
  function announce(player) {
    const target = player?.isConnected ? player : document;
    target.dispatchEvent(new Event('fullscreenchange', { bubbles: true }));
    target.dispatchEvent(new Event('webkitfullscreenchange', { bubbles: true }));
    // CSS expansion does not resize the browser. Let players (including YouTube)
    // recalculate pixel-sized controls after their fullscreen handlers run.
    cancelAnimationFrame(resizeFrame);
    resizeFrame = requestAnimationFrame(() => {
      resizeFrame = 0;
      window.dispatchEvent(new Event('resize'));
    });
  }
  function stopYouTubeLayout() {
    if (!youtubeLayout) return;
    youtubeLayout.observer.disconnect();
    cancelAnimationFrame(youtubeLayout.frame);
    for (const timer of youtubeLayout.timers) clearTimeout(timer);
    youtubeLayout = null;
  }
  function startYouTubeLayout(player) {
    stopYouTubeLayout();
    if (!youtubeSite || !player.matches(YOUTUBE_PLAYER)) return;
    const session = {
      frame: 0,
      timers: [],
      width: 0,
      height: 0,
      route: location.pathname,
    };
    session.sync = (force = false) => {
      if (youtubeLayout !== session) return;
      if (!player.isConnected || location.pathname !== session.route) {
        stopYouTubeLayout();
        return;
      }
      const { width, height } = player.getBoundingClientRect();
      if (width <= 0 || height <= 0) return;
      if (!force && width === session.width && height === session.height) return;
      // YouTube can ignore window resize events when the viewport itself has not
      // changed. Feature-detect its player sizing hooks; neither is a DOM API.
      const resize =
        typeof player.setInternalSize === 'function'
          ? player.setInternalSize
          : player.setSize;
      if (typeof resize !== 'function') return;
      const properties = ['width', 'height'];
      const previous = properties.map((name) => [
        player.style.getPropertyValue(name),
        player.style.getPropertyPriority(name),
      ]);
      try {
        resize.call(player, width, height);
        session.width = width;
        session.height = height;
      } catch {
        // A changed site API must not break entry, Escape, or native page layout.
      } finally {
        // Some player variants also write the outer dimensions. Keep the page's
        // responsive CSS in charge of that box, especially after leaving FrameFit.
        properties.forEach((name, index) => {
          const [value, priority] = previous[index];
          if (value) player.style.setProperty(name, value, priority);
          else player.style.removeProperty(name);
        });
      }
    };
    session.queue = () => {
      if (session.frame || youtubeLayout !== session) return;
      session.frame = requestAnimationFrame(() => {
        session.frame = 0;
        session.sync();
      });
    };
    session.observer = new ResizeObserver(session.queue);
    youtubeLayout = session;
    session.observer.observe(player);
    session.queue();
    session.timers.push(setTimeout(() => session.sync(true), 250));
  }
  function restoreYouTubeLayout() {
    const session = youtubeLayout;
    if (!session) return;
    session.width = session.height = 0;
    session.queue();
    // YouTube's internal size can remain pinned after exit. Keep observing this
    // player so later window/theater resizing also updates its video and controls.
    // ResizeObserver is event-driven; there is no idle polling or frame loop.
    session.timers.push(
      setTimeout(() => session.sync(true), 250),
      setTimeout(() => {
        if (youtubeLayout !== session) return;
        session.sync(true);
      }, 1000),
    );
  }
  function sendParent(enabled) {
    if (window !== top)
      parent.postMessage({ channel: MESSAGE, type: 'state', active: enabled }, '*');
  }
  function sizePlayer() {
    if (!active) return;
    const ancestors = new Set();
    for (
      let p = active.parentElement;
      p && p !== document.documentElement;
      p = p.parentElement
    )
      ancestors.add(p);
    // Responsive players can move between page containers without being replaced.
    // Drop the old path so it cannot keep hiding the newly selected branch.
    for (const [element, names] of marked) {
      if (names.has('uvtf-path') && !ancestors.has(element)) {
        element.classList.remove('uvtf-path');
        names.delete('uvtf-path');
        if (!names.size) marked.delete(element);
      }
    }
    for (const element of ancestors) mark(element, 'uvtf-path');
    for (const video of active.querySelectorAll('video')) {
      for (let p = video.parentElement; p && p !== active; p = p.parentElement)
        mark(p, 'uvtf-video-path');
    }
  }
  function enter(player, childWindow = null) {
    if (!settings.enabled || !player?.isConnected || player === document.documentElement)
      return;
    if (active === player) return;
    if (active) leave();
    active = player;
    child = childWindow;
    focusBefore = document.activeElement;
    scrollBefore = { left: scrollX, top: scrollY };
    route = location.pathname;
    mark(document.documentElement, 'uvtf-active');
    mark(player, 'uvtf-player');
    sizePlayer();
    startYouTubeLayout(player);
    if (window === top) {
      exitButton = document.createElement('button');
      exitButton.className = 'uvtf-exit';
      exitButton.type = 'button';
      labelExitButton();
      exitButton.addEventListener('click', (event) => {
        event.stopPropagation();
        leave();
      });
      document.body.append(exitButton);
    }
    layoutObserver.observe(document, { childList: true, subtree: true });
    announce(player);
    sendParent(true);
  }
  function labelExitButton() {
    if (!exitButton) return;
    const compact = settings.mode === 'compact';
    exitButton.textContent = compact ? 'Return to tab · Esc' : 'Return to page · Esc';
    exitButton.title = compact
      ? 'Move this video back to its browser tab and restore the normal page'
      : 'Restore the normal page layout';
  }
  function leave(notifyChild = true) {
    if (!active) return;
    layoutObserver.disconnect();
    cancelAnimationFrame(layoutFrame);
    layoutFrame = 0;
    const old = active,
      oldChild = child;
    active = null;
    child = null;
    exitButton?.remove();
    exitButton = null;
    for (const [element, names] of marked)
      for (const name of names) element.classList.remove(name);
    marked.clear();
    if (notifyChild && oldChild)
      oldChild.postMessage({ channel: MESSAGE, type: 'exit' }, '*');
    announce(old);
    restoreYouTubeLayout();
    sendParent(false);
    if (focusBefore?.isConnected) focusBefore.focus({ preventScroll: true });
    if (scrollBefore && location.pathname === route)
      window.scrollTo({ ...scrollBefore, behavior: 'instant' });
    focusBefore = null;
    scrollBefore = null;
  }
  function toggle(player) {
    if (settings.mode === 'pip') {
      requestPip(player).catch(showPipError);
      return;
    }
    active ? leave() : enter(player);
  }

  function showPipError(error) {
    notice?.remove();
    clearTimeout(noticeTimer);
    notice = document.createElement('div');
    notice.className = 'uvtf-notice';
    notice.setAttribute('role', 'status');
    notice.textContent =
      error.name === 'NotAllowedError'
        ? 'Click the video fullscreen button again to open Picture-in-Picture.'
        : 'Picture-in-Picture is unavailable for this video. Try Fill current tab in FrameFit.';
    document.body?.append(notice);
    noticeTimer = setTimeout(() => {
      notice?.remove();
      notice = null;
    }, 6000);
  }

  async function closePip() {
    if (pipVideo && document.pictureInPictureElement === pipVideo)
      await document.exitPictureInPicture();
    pipVideo = null;
  }

  function requestPip(player) {
    if (pipRequest) return pipRequest;
    if (pipVideo && document.pictureInPictureElement === pipVideo) return closePip();
    const video = player?.tagName === 'VIDEO' ? player : chooseVideo(player || document);
    if (
      !video ||
      !document.pictureInPictureEnabled ||
      typeof video.requestPictureInPicture !== 'function' ||
      video.disablePictureInPicture ||
      video.readyState === 0
    )
      return Promise.reject(new Error('Picture-in-Picture unavailable'));
    const generation = pipGeneration;
    // Invoke directly in the click/key handler so Chrome retains user activation.
    try {
      pipRequest = video
        .requestPictureInPicture()
        .then(async () => {
          clearTimeout(noticeTimer);
          notice?.remove();
          notice = null;
          pipVideo = video;
          if (
            generation !== pipGeneration ||
            !settings.enabled ||
            settings.mode !== 'pip'
          ) {
            await closePip();
            return;
          }
          video.addEventListener(
            'leavepictureinpicture',
            () => {
              if (pipVideo === video) pipVideo = null;
            },
            { once: true },
          );
        })
        .finally(() => {
          pipRequest = null;
        });
    } catch (error) {
      return Promise.reject(error);
    }
    return pipRequest;
  }

  function visibleVideos(root = document) {
    return Array.from(root.querySelectorAll('video')).filter((video) => {
      const r = video.getBoundingClientRect();
      return (
        r.width > 40 && r.height > 30 && getComputedStyle(video).visibility !== 'hidden'
      );
    });
  }
  function chooseVideo(root = document) {
    const videos = visibleVideos(root);
    if (pointer) {
      const hovered = videos.find((v) => {
        const r = v.getBoundingClientRect();
        return (
          pointer.x >= r.left &&
          pointer.x <= r.right &&
          pointer.y >= r.top &&
          pointer.y <= r.bottom
        );
      });
      if (hovered) return hovered;
    }
    return videos.sort((a, b) => {
      const ar = a.getBoundingClientRect(),
        br = b.getBoundingClientRect();
      return (
        Number(a.paused) - Number(b.paused) || br.width * br.height - ar.width * ar.height
      );
    })[0];
  }
  function containerFor(video) {
    if (xSite) {
      const known = video.closest(X_PLAYER);
      if (known) return known;
    }
    if (youtubeSite) {
      const known = video.closest(YOUTUBE_PLAYER);
      if (known) return known;
    }
    // Crunchyroll's wrapper was verified against its live DOM.
    if (location.hostname === 'www.crunchyroll.com') {
      const known = video.closest('#player-container');
      if (known) return known;
    }
    if (twitchSite) {
      const known = video.closest(TWITCH_PLAYER);
      if (known) return known;
    }
    const vr = video.getBoundingClientRect();
    let best = video;
    for (
      let p = video.parentElement, depth = 0;
      p && p !== document.body && depth < 8;
      p = p.parentElement, depth++
    ) {
      const r = p.getBoundingClientRect();
      if (
        p.querySelectorAll('video').length > 1 ||
        r.width > vr.width * 1.4 ||
        r.height > vr.height * 1.8
      )
        break;
      if (r.width >= vr.width * 0.8 && r.height >= vr.height * 0.8) best = p;
    }
    return best;
  }
  function targetFor(requested) {
    if (xSite) {
      const known = requested.closest(X_PLAYER);
      if (known?.querySelector('video')) return known;
    }
    if (youtubeSite) {
      const known = requested.closest(YOUTUBE_PLAYER);
      if (known?.querySelector('video')) return known;
    }
    // Twitch can request fullscreen from its controls layer, a sibling of the video.
    if (twitchSite) {
      const known = requested.closest(TWITCH_PLAYER);
      if (known?.querySelector('video')) return known;
    }
    if (requested === document.body || requested === document.documentElement) {
      const video = chooseVideo();
      return video ? containerFor(video) : null;
    }
    if (requested.tagName === 'VIDEO') return containerFor(requested);
    // A player's requested fullscreen element is more reliable than guessing its wrapper.
    if (requested.tagName === 'IFRAME' || requested.querySelector('video,iframe'))
      return requested;
    return null;
  }

  for (const method of [
    'requestFullscreen',
    'webkitRequestFullscreen',
    'webkitRequestFullScreen',
  ]) {
    const original = Element.prototype[method];
    if (!original) continue;
    Element.prototype[method] = function (...args) {
      if (!settings.enabled) return original.apply(this, args);
      const player = targetFor(this);
      if (!player) return original.apply(this, args);
      if (settings.mode === 'pip') {
        const request = requestPip(player);
        request.catch(showPipError);
        return request;
      }
      enter(player);
      return Promise.resolve();
    };
  }
  for (const method of [
    'exitFullscreen',
    'webkitExitFullscreen',
    'webkitCancelFullScreen',
  ]) {
    const original = Document.prototype[method];
    if (!original) continue;
    Document.prototype[method] = function (...args) {
      if (this === document && pipVideo) return closePip();
      if (this === document && active) {
        leave();
        return Promise.resolve();
      }
      return original.apply(this, args);
    };
  }
  for (const name of ['fullscreenElement', 'webkitFullscreenElement']) {
    const descriptor = Object.getOwnPropertyDescriptor(Document.prototype, name);
    if (descriptor?.get && descriptor.configurable)
      Object.defineProperty(Document.prototype, name, {
        ...descriptor,
        get() {
          return (this === document && active) || descriptor.get.call(this);
        },
      });
  }

  function trackPointer(event) {
    pointer = { x: event.clientX, y: event.clientY };
  }
  window.addEventListener(
    'keydown',
    (event) => {
      if (!settings.enabled) return;
      const editing =
        event.target instanceof Element &&
        (event.target.isContentEditable ||
          event.target.closest('input,textarea,select,[role="textbox"]'));
      if (event.key === 'Escape' && active) {
        event.preventDefault();
        event.stopImmediatePropagation();
        leave();
      } else if (event.key === 'Escape' && pipVideo) {
        event.preventDefault();
        event.stopImmediatePropagation();
        closePip().catch(showPipError);
      } else if (
        twitchSite &&
        event.key.toLowerCase() === 'f' &&
        !event.ctrlKey &&
        !event.altKey &&
        !event.metaKey &&
        !editing &&
        !event.repeat
      ) {
        const video = chooseVideo();
        const player = video?.closest(TWITCH_PLAYER);
        if (!player) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        toggle(player);
      } else if (
        event.altKey &&
        event.shiftKey &&
        event.code === 'KeyV' &&
        !editing &&
        !event.repeat
      ) {
        const video = chooseVideo();
        if (!active && !video && !pipVideo) return;
        event.preventDefault();
        event.stopImmediatePropagation();
        toggle(video ? containerFor(video) : null);
      }
    },
    true,
  );
  // Capture verified site controls before their own fullscreen event handlers.
  window.addEventListener(
    'click',
    (event) => {
      if (!settings.enabled) return;
      if (event.button !== 0 || !(event.target instanceof Element)) return;
      let player;
      if (twitchSite) {
        const button = event.target.closest(TWITCH_BUTTON);
        player = button?.closest(TWITCH_PLAYER);
      } else if (youtubeSite) {
        const button = event.target.closest('.ytp-fullscreen-button');
        player = button?.closest(YOUTUBE_PLAYER);
      } else if (xSite) {
        const button = event.target.closest(
          'button[aria-label="Full screen"],button[aria-label="Exit full screen"]',
        );
        player = button?.closest(X_PLAYER);
      } else if (location.hostname === 'www.crunchyroll.com') {
        const button = event.target.closest('[data-testid="fullscreen-button"]');
        player = button?.closest('#player-container');
      }
      if (!player) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      toggle(player);
    },
    true,
  );

  // Expand each ancestor iframe, without accessing cross-origin frame documents.
  window.addEventListener('message', (event) => {
    const data = event.data;
    if (!data || data.channel !== MESSAGE) return;
    if (data.type === 'settings' && window !== top && event.source === parent) {
      applySettings(data.settings);
      return;
    }
    if (data.type === 'exit' && window !== top && event.source === parent) {
      leave();
      return;
    }
    const frame = Array.from(document.querySelectorAll('iframe')).find(
      (f) => f.contentWindow === event.source,
    );
    if (!frame) return;
    if (data.type === 'ready') {
      frame.contentWindow.postMessage(
        { channel: MESSAGE, type: 'settings', settings },
        '*',
      );
      return;
    }
    if (data.type !== 'state' || typeof data.active !== 'boolean') return;
    if (data.active) enter(frame, event.source);
    else if (child === event.source) leave(false);
  });
  const layoutObserver = new MutationObserver((records) => {
    if (!active) return;
    if (!active.isConnected || location.pathname !== route) leave();
    else {
      if (exitButton && !exitButton.isConnected) document.body.append(exitButton);
      const relevant = records.some(
        (record) =>
          active.contains(record.target) ||
          [...record.addedNodes].some((node) => node === active || node.contains(active)),
      );
      if (layoutFrame || !relevant) return;
      layoutFrame = requestAnimationFrame(() => {
        layoutFrame = 0;
        sizePlayer();
      });
    }
  });
  window.addEventListener('popstate', () => {
    if (active) leave();
    stopYouTubeLayout();
  });
  if (youtubeSite)
    document.addEventListener('yt-navigate-start', () => {
      leave();
      stopYouTubeLayout();
    });
  window.addEventListener('pagehide', () => {
    leave();
    stopYouTubeLayout();
    cancelAnimationFrame(resizeFrame);
    resizeFrame = 0;
    pipGeneration++;
    closePip().catch(() => {});
    clearTimeout(noticeTimer);
    notice?.remove();
    notice = null;
  });
  function connectSettings() {
    readSettings();
    if (window !== top) parent.postMessage({ channel: MESSAGE, type: 'ready' }, '*');
  }
  connectSettings();
  document.addEventListener('DOMContentLoaded', connectSettings, { once: true });
  window.addEventListener('pageshow', connectSettings);
})();

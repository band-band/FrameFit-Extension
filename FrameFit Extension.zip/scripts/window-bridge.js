(() => {
  'use strict';
  let previous;
  let settings = { enabled: false, mode: 'compact' };
  let revision = 0;
  let retryTimer;
  let retryCount = 0;
  function sync(force = false) {
    const active =
      settings.enabled &&
      settings.mode === 'compact' &&
      document.documentElement.classList.contains('uvtf-active');
    if (active === previous && !force) return;
    previous = active;
    chrome.runtime
      .sendMessage({ type: 'uvtf-window', active })
      .then((result) => {
        if (result?.error) {
          previous = undefined;
          console.warn('FrameFit: compact window unavailable.', result.error);
        }
      })
      .catch((error) => {
        previous = undefined;
        console.warn(
          'FrameFit: reload this page if the extension was updated.',
          error.message,
        );
      });
  }
  async function refresh(retry = false) {
    clearTimeout(retryTimer);
    if (!retry) retryCount = 0;
    const request = ++revision;
    try {
      const result = await chrome.runtime.sendMessage({ type: 'framefit-settings' });
      if (request !== revision) return;
      if (
        result?.error ||
        typeof result?.enabled !== 'boolean' ||
        !['compact', 'tab', 'pip'].includes(result.mode)
      )
        throw new Error(result?.error || 'Settings are not ready.');
      retryCount = 0;
      settings = {
        enabled: result?.enabled === true,
        mode: result.mode,
        confirmClose: result.confirmClose !== false,
        hideCompactTip: result.hideCompactTip === true,
      };
      document.documentElement.setAttribute(
        'data-framefit-settings',
        JSON.stringify(settings),
      );
      document.dispatchEvent(new Event('framefit-settings'));
      sync(true);
    } catch (error) {
      if (request !== revision) return;
      if (retryCount < 5) {
        retryTimer = setTimeout(() => refresh(true), 250 * 2 ** retryCount++);
        return;
      }
      console.warn('FrameFit: reload this page to connect settings.', error.message);
    }
  }
  function start() {
    new MutationObserver(() => sync()).observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class'],
    });
    chrome.storage.onChanged.addListener((changes, area) => {
      if (
        area === 'local' &&
        [
          'framefitEnabled',
          'framefitMode',
          'framefitDisabledSites',
          'framefitConfirmClose',
          'framefitHideCompactTip',
        ].some((key) => key in changes)
      )
        refresh();
    });
    window.addEventListener('pageshow', () => refresh());
    refresh();
  }
  if (document.documentElement) start();
  else {
    const ready = new MutationObserver(() => {
      if (document.documentElement) {
        ready.disconnect();
        start();
      }
    });
    ready.observe(document, { childList: true });
  }
})();

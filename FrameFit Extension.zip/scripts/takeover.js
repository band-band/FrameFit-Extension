(() => {
  'use strict';
  let session = null,
    pending = null,
    generation = 0;
  function close() {
    generation++;
    session?.restore();
  }
  function open(video) {
    if (session) {
      close();
      return Promise.resolve();
    }
    if (pending) return pending;
    if (
      window !== top ||
      !window.documentPictureInPicture?.requestWindow ||
      !video?.isConnected ||
      !video.readyState ||
      video.disablePictureInPicture
    )
      return Promise.reject(new Error('Takeover unavailable'));
    const token = generation;
    // Request synchronously within the user's click to preserve activation.
    let request;
    try {
      request = window.documentPictureInPicture.requestWindow({
        width: 800,
        height: 500,
      });
    } catch (error) {
      return Promise.reject(error);
    }
    pending = request
      .then((floating) => {
        if (token !== generation || !video.isConnected) {
          floating.close();
          return;
        }
        const parent = video.parentNode,
          next = video.nextSibling;
        const marker = document.createComment('FrameFit Takeover');
        const styles = [
          'width',
          'height',
          'max-width',
          'max-height',
          'min-width',
          'min-height',
          'position',
          'top',
          'right',
          'bottom',
          'left',
          'margin-top',
          'margin-right',
          'margin-bottom',
          'margin-left',
          'transform',
          'object-fit',
        ];
        const previous = styles.map((name) => [
          name,
          video.style.getPropertyValue(name),
          video.style.getPropertyPriority(name),
        ]);
        const hadControls = video.controls;
        const wasPlaying = !video.paused && !video.ended;
        const listeners = [];
        let restored = false;
        const on = (target, type, handler) => {
          target.addEventListener(type, handler);
          listeners.push(() => target.removeEventListener(type, handler));
        };
        const observer = new MutationObserver(() => {
          if (!marker.isConnected || video.ownerDocument !== floating.document) close();
        });
        const restore = () => {
          if (restored) return;
          restored = true;
          observer.disconnect();
          listeners.forEach((remove) => remove());
          const resume = !video.paused && !video.ended;
          if (video.ownerDocument === floating.document) {
            if (marker.parentNode) marker.replaceWith(video);
            else parent.insertBefore(video, next?.parentNode === parent ? next : null);
          }
          marker.remove();
          video.controls = hadControls;
          for (const [name, value, priority] of previous) {
            if (value) video.style.setProperty(name, value, priority);
            else video.style.removeProperty(name);
          }
          if (session?.restore === restore) session = null;
          floating.close();
          if (resume && video.paused) video.play().catch(() => {});
          window.dispatchEvent(new Event('resize'));
        };
        session = { restore };
        try {
          parent.insertBefore(marker, video);
          const doc = floating.document;
          doc.title = 'FrameFit Takeover';
          const style = doc.createElement('style');
          style.textContent = `html,body{margin:0;height:100%;background:#10131a;color:#f5f6fa;font:14px system-ui}body{display:flex;flex-direction:column}main{flex:1;min-height:0;display:flex}video{background:#000}footer{padding:12px;display:flex;gap:8px;align-items:center;flex-wrap:wrap}button,input{accent-color:#a99aff}button{background:#292d3b;color:inherit;border:1px solid #555b70;border-radius:8px;padding:8px;cursor:pointer}button:focus-visible,input:focus-visible{outline:2px solid #a99aff}input[type=range]{min-width:70px;width:110px}output{font-variant-numeric:tabular-nums}#seek{flex:1}#return{margin-left:auto}`;
          doc.head.append(style);
          const main = doc.createElement('main'),
            bar = doc.createElement('footer');
          bar.setAttribute('aria-label', 'Playback controls');
          doc.body.append(main, bar);
          const button = (label, action, id) => {
            const el = doc.createElement('button');
            el.textContent = label;
            if (id) el.id = id;
            on(el, 'click', action);
            bar.append(el);
            return el;
          };
          const play = button('Play', () => {
            if (video.paused)
              video.play().catch(() => {
                play.textContent = 'Try play again';
              });
            else video.pause();
          });
          const seek = doc.createElement('input');
          seek.type = 'range';
          seek.id = 'seek';
          seek.setAttribute('aria-label', 'Seek');
          seek.step = '0.1';
          bar.append(seek);
          const time = doc.createElement('output');
          bar.append(time);
          const mute = button('Mute', () => {
            video.muted = !video.muted;
          });
          const volume = doc.createElement('input');
          volume.type = 'range';
          volume.min = '0';
          volume.max = '1';
          volume.step = '0.05';
          volume.setAttribute('aria-label', 'Volume');
          bar.append(volume);
          button('Return to tab', close, 'return');
          const format = (n) =>
            Number.isFinite(n)
              ? Math.floor(n / 60) + ':' + String(Math.floor(n % 60)).padStart(2, '0')
              : 'Live';
          const update = () => {
            play.textContent = video.paused ? 'Play' : 'Pause';
            mute.textContent = video.muted ? 'Unmute' : 'Mute';
            volume.value = String(video.volume);
            const finite = Number.isFinite(video.duration) && video.duration > 0;
            seek.disabled = !finite;
            seek.max = String(finite ? video.duration : 1);
            seek.value = String(finite ? video.currentTime : 0);
            time.textContent = format(video.currentTime) + ' / ' + format(video.duration);
          };
          on(seek, 'input', () => {
            if (Number.isFinite(video.duration)) video.currentTime = Number(seek.value);
          });
          on(volume, 'input', () => {
            video.volume = Number(volume.value);
            video.muted = false;
          });
          for (const event of [
            'play',
            'pause',
            'timeupdate',
            'durationchange',
            'volumechange',
            'loadedmetadata',
            'ended',
          ])
            on(video, event, update);
          on(floating, 'pagehide', restore);
          on(floating, 'keydown', (event) => {
            if (event.key === 'Escape') {
              event.preventDefault();
              close();
            }
          });
          for (const name of styles)
            video.style.setProperty(
              name,
              ['width', 'height', 'max-width', 'max-height'].includes(name)
                ? '100%'
                : name === 'position'
                  ? 'static'
                  : name === 'object-fit'
                    ? 'contain'
                    : name === 'transform'
                      ? 'none'
                      : '0',
              'important',
            );
          video.controls = false;
          main.append(video);
          observer.observe(document, { childList: true, subtree: true });
          update();
          if (wasPlaying && video.paused)
            video.play().catch(() => {
              play.textContent = 'Play';
            });
        } catch (error) {
          restore();
          throw error;
        }
      })
      .finally(() => {
        pending = null;
      });
    return pending;
  }
  window.FrameFitTakeover = {
    open,
    close,
    get active() {
      return Boolean(session || pending);
    },
  };
})();

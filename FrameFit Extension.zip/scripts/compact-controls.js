(() => {
  'use strict';
  let settings = {};
  let host;
  let dismissed = false;
  let guarding = false;
  function compact() {
    return (
      settings.enabled === true &&
      settings.mode === 'compact' &&
      document.documentElement.classList.contains('uvtf-active')
    );
  }
  function confirmLeave(event) {
    if (!compact() || settings.confirmClose === false) return;
    event.preventDefault();
    event.returnValue = '';
  }
  function update() {
    const active = compact();
    const protect = active && settings.confirmClose !== false;
    if (protect !== guarding) {
      window[protect ? 'addEventListener' : 'removeEventListener'](
        'beforeunload',
        confirmLeave,
      );
      guarding = protect;
    }
    if (!active || dismissed || settings.hideCompactTip === true) {
      host?.remove();
      host = null;
      return;
    }
    if (host) {
      if (!host.isConnected) document.documentElement.append(host);
      return;
    }
    host = document.createElement('div');
    host.id = 'framefit-compact-controls';
    host.style.cssText =
      'all:initial!important;position:fixed!important;left:12px!important;bottom:12px!important;z-index:2147483647!important;width:min(340px,calc(100vw - 24px))!important;';
    const root = host.attachShadow({ mode: 'open' });
    root.innerHTML = `<style>
      :host{color-scheme:light}*{box-sizing:border-box}
      .panel{font:13px/1.5 system-ui,sans-serif;color:#2c233b;background:#faf7ff;border:1px solid #d6c5ee;border-radius:16px;padding:14px;box-shadow:0 4px 20px #0003}
      h2{font-size:15px;margin:0 0 6px}p{margin:0 0 10px}label{display:flex;align-items:center;gap:6px}
      button{font:inherit;border:1px solid #b99edc;border-radius:10px;padding:7px 12px;background:#eee5fb;color:#38234f;cursor:pointer}
      button:focus-visible,input:focus-visible{outline:2px solid #7951b4;outline-offset:2px}
      section button{margin:10px 0}#feedback:empty{display:none}
    </style><div class="panel"><section aria-label="Compact view guidance"><h2>Keep your video open</h2>
    <p>Use <strong>Return to tab</strong> or <strong>Esc</strong> to go back. <strong>X closes the video tab.</strong></p>
    <label><input id="hide-tip" type="checkbox">Don't show this tip again</label><button id="dismiss" type="button">Got it</button></section>
    <span id="feedback" role="status"></span></div>`;
    root.querySelector('#dismiss').addEventListener('click', async () => {
      const feedback = root.querySelector('#feedback');
      try {
        if (root.querySelector('#hide-tip').checked)
          await chrome.storage.local.set({ framefitHideCompactTip: true });
        dismissed = true;
        update();
      } catch {
        feedback.textContent = 'Could not save. Try again.';
      }
    });
    document.documentElement.append(host);
  }
  function readSettings() {
    try {
      settings = JSON.parse(
        document.documentElement.getAttribute('data-framefit-settings') || '{}',
      );
    } catch {
      settings = {};
    }
    update();
  }
  function start() {
    new MutationObserver(update).observe(document.documentElement, {
      attributes: true,
      attributeFilter: ['class'],
    });
    document.addEventListener('framefit-settings', readSettings);
    window.addEventListener('pageshow', readSettings);
    readSettings();
  }
  if (document.documentElement) start();
  else document.addEventListener('DOMContentLoaded', start, { once: true });
})();

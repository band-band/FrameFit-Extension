'use strict';
importScripts('settings.js');
const jobs = new Map();
const keyFor = (tabId) => `uvtf-window-${tabId}`;

// Keep rapid enter/exit requests in order, including while a popup is being created.
function serialize(tabId, operation) {
  const next = (jobs.get(tabId) || Promise.resolve()).catch(() => {}).then(operation);
  jobs.set(tabId, next);
  next
    .finally(() => {
      if (jobs.get(tabId) === next) jobs.delete(tabId);
    })
    .catch(() => {});
  return next;
}
async function setCompact(tabId, active) {
  const key = keyFor(tabId);
  const saved = (await chrome.storage.session.get(key))[key];
  const tab = await chrome.tabs.get(tabId);
  if (active) {
    if (saved?.popupId === tab.windowId) return;
    const source = await chrome.windows.get(tab.windowId);
    if (source.type !== 'normal') return;
    const record = {
      originalId: source.id,
      index: tab.index,
      pinned: tab.pinned,
      bounds: {
        left: source.left,
        top: source.top,
        width: source.width,
        height: source.height,
      },
      maximized: source.state === 'maximized',
    };
    const options = { tabId, type: 'popup', focused: true };
    if (record.maximized) options.state = 'maximized';
    else Object.assign(options, record.bounds);
    // Moving the existing tab preserves the page, rather than loading a second copy.
    const popup = await chrome.windows.create(options);
    record.popupId = popup.id;
    await chrome.storage.session.set({ [key]: record });
    return;
  }
  if (!saved) return;
  if (tab.windowId !== saved.popupId) {
    await chrome.storage.session.remove(key);
    return;
  }
  let destination;
  try {
    destination = await chrome.windows.get(saved.originalId);
  } catch {
    // The original window may have closed when its last tab moved out.
  }
  if (destination?.type === 'normal') {
    await chrome.tabs.move(tabId, { windowId: destination.id, index: saved.index });
    await chrome.tabs.update(tabId, { active: true, pinned: saved.pinned });
    await chrome.windows.update(destination.id, { focused: true });
  } else {
    // Chrome closes windows when the last tab moves; recreate one if needed.
    const options = { tabId, type: 'normal', focused: true };
    if (saved.maximized) options.state = 'maximized';
    else Object.assign(options, saved.bounds);
    await chrome.windows.create(options);
    await chrome.tabs.update(tabId, { active: true, pinned: saved.pinned });
  }
  await chrome.storage.session.remove(key);
}
chrome.runtime.onMessage.addListener((message, sender, respond) => {
  if (sender.frameId !== 0 || !Number.isInteger(sender.tab?.id)) return;
  try {
    if (!['http:', 'https:'].includes(new URL(sender.url).protocol)) return;
  } catch {
    return;
  }
  if (message?.type === 'framefit-settings') {
    FrameFitSettings.read().then(
      (settings) => respond(FrameFitSettings.effective(settings, sender.url)),
      (error) => respond({ enabled: false, mode: 'compact', error: error.message }),
    );
    return true;
  }
  if (message?.type !== 'uvtf-window' || typeof message.active !== 'boolean') return;
  serialize(sender.tab.id, async () => {
    // Exiting must still work if preference storage is temporarily unavailable.
    if (!message.active) return setCompact(sender.tab.id, false);
    const settings = FrameFitSettings.effective(
      await FrameFitSettings.read(),
      sender.url,
    );
    return setCompact(sender.tab.id, settings.enabled && settings.mode === 'compact');
  }).then(
    () => respond({ ok: true }),
    (error) => respond({ error: error.message }),
  );
  return true;
});
chrome.tabs.onRemoved.addListener((tabId) => {
  serialize(tabId, () => chrome.storage.session.remove(keyFor(tabId))).catch(() => {});
});
